package com.chiragbohet.RESTfulwebservices2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTfulWebServices2Application {

	public static void main(String[] args) {
		SpringApplication.run(ResTfulWebServices2Application.class, args);
	}

}
